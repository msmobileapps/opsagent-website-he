'use client';

import { useState } from 'react';
import { agents as mockAgents, executionLogs } from '@/lib/mock-data';
import { useApi } from '@/lib/use-api';
import { addToast } from '@/components/toast';
import { useDocViewer } from '@/components/doc-context';
import {
  Activity,
  CheckCircle2,
  Clock,
  Zap,
  AlertTriangle,
  FileText,
  Send,
  Eye,
  Phone,
  Calendar,
  Pencil,
  X,
  Download,
  UserPlus,
} from 'lucide-react';

function StatCard({ icon: Icon, label, value, sub }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="bg-surface-raised border border-surface-border rounded-xl p-4">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-8 h-8 rounded-lg bg-brand-500/10 flex items-center justify-center">
          <Icon className="w-4 h-4 text-brand-400" />
        </div>
        <span className="text-xs text-gray-500 uppercase tracking-wider">{label}</span>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
    </div>
  );
}

interface AttentionItem {
  id: string;
  agent: string;
  text: string;
  priority: 'urgent' | 'high' | 'medium';
  actions: string[];
  docId?: string;
  docName?: string;
}

const initialAttentionItems: AttentionItem[] = [
  {
    id: '1',
    agent: 'Lead Pipeline',
    text: 'Hot lead from Angi — $45K kitchen remodel in River Oaks. Rep Sarah assigned but hasn\'t called in 2 hours.',
    priority: 'urgent',
    actions: ['View Lead', 'Send SMS', 'Dismiss'],
    docId: '1', docName: 'Proposal — Martinez Bathroom Remodel',
  },
  {
    id: '2',
    agent: 'Project Tracker',
    text: 'Jenkins kitchen reno 4 days behind — countertop templating delayed, client called twice today.',
    priority: 'urgent',
    actions: ['View Project', 'Contact Client', 'Dismiss'],
  },
  {
    id: '3',
    agent: 'Financing Engine',
    text: 'GreenSky preapproval for Martinez family ($38K bathroom) expires tomorrow — deal not signed yet.',
    priority: 'high',
    actions: ['View Deal', 'Send Reminder', 'Dismiss'],
  },
  {
    id: '4',
    agent: 'Subcontractor Manager',
    text: 'Elite Electric\'s insurance expires March 29 — assigned to 3 active projects this week.',
    priority: 'urgent',
    actions: ['View Sub', 'Send Renewal', 'Pause Jobs'],
  },
  {
    id: '5',
    agent: 'Receipts Collector',
    text: '2 invoices from ABC Supply ($8,400) don\'t match any open PO — possible overcharge.',
    priority: 'high',
    actions: ['View Invoice', 'Find PO', 'Contact Vendor'],
  },
  {
    id: '6',
    agent: 'Sales Performance',
    text: 'Rep Derek\'s close rate dropped to 18% this month (team avg 38%) — coaching session needed.',
    priority: 'medium',
    actions: ['View Profile', 'Schedule Coaching', 'Dismiss'],
  },
];

const recentDocuments = [
  { id: '1', name: 'Proposal — Martinez Bathroom Remodel', type: 'PDF', agent: 'Financing Engine', date: 'Mar 27', size: '$38K' },
  { id: '2', name: 'Subcontractor Comparison — Plumbers Q2', type: 'XLSX', agent: 'Sub Shopping', date: 'Mar 25', size: '8 subs' },
  { id: '3', name: 'Weekly Campaign Report — Mar 23', type: 'PDF', agent: 'Campaign Performance', date: 'Mar 23', size: '$38K spend' },
  { id: '4', name: 'Invoice #ACM-2026-312 — Jenkins Kitchen', type: 'PDF', agent: 'Salesforce Sync', date: 'Mar 20', size: '$52K' },
  { id: '5', name: 'Project Schedule — Henderson Whole Home', type: 'PDF', agent: 'Project Tracker', date: 'Mar 22', size: '12 weeks' },
  { id: '6', name: 'Commission Statement — Sarah Chen Q1', type: 'XLSX', agent: 'Payroll & Commissions', date: 'Mar 14', size: '$18.4K' },
];

const priorityStyles = {
  urgent: 'border-red-500/30 bg-red-500/10',
  high: 'border-yellow-500/30 bg-yellow-500/10',
  medium: 'border-blue-500/30 bg-blue-500/10',
};

const priorityLabels = {
  urgent: { text: 'Urgent', color: 'text-red-400 bg-red-500/20' },
  high: { text: 'High', color: 'text-yellow-400 bg-yellow-500/20' },
  medium: { text: 'Medium', color: 'text-blue-400 bg-blue-500/20' },
};

const tagStyles: Record<string, string> = {
  PDF: 'bg-blue-500/20 text-blue-400',
  XLSX: 'bg-green-500/20 text-green-400',
  DOC: 'bg-purple-500/20 text-purple-400',
};

const actionIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  'Send Follow-up': Send,
  'Call Contact': Phone,
  'Call Client': Phone,
  'Dismiss': X,
  'Generate Proposal': Pencil,
  'Schedule Call': Phone,
  'Schedule Demo': Calendar,
  'View Email': Eye,
  'Send Draft Reply': Send,
  'Review Now': Eye,
  'Approve & Send': Send,
  'Upload Receipts': Download,
  'View Details': Eye,
  'View Reply': Eye,
  'Add to Segment': UserPlus,
  'View Lead': Eye,
  'Send SMS': Send,
  'View Project': Eye,
  'Contact Client': Phone,
  'View Deal': Eye,
  'Send Reminder': Send,
  'View Sub': Eye,
  'Send Renewal': Send,
  'Pause Jobs': X,
  'View Invoice': Eye,
  'Find PO': Pencil,
  'Contact Vendor': Phone,
  'View Profile': Eye,
  'Schedule Coaching': Calendar,
};

// Demo action messages — richer feedback for different action types
const actionFeedback: Record<string, { message: string; type: 'success' | 'info' }> = {
  'Send Follow-up': { message: 'Follow-up email drafted and sent to contact. Calendar reminder set for 48h check-in.', type: 'success' },
  'Call Contact': { message: 'Initiating call... Opening dialer for contact. Call notes template loaded.', type: 'info' },
  'Call Client': { message: 'Initiating call... Opening dialer. Previous call notes and project history loaded.', type: 'info' },
  'Generate Proposal': { message: 'Proposal Generator agent started. Template selected, pricing calculated. Draft will be ready in ~3 minutes.', type: 'success' },
  'Schedule Call': { message: 'Finding available slots... Call scheduled for tomorrow at 14:00. Calendar invite sent to contact.', type: 'success' },
  'Schedule Demo': { message: 'Demo scheduled for Thursday at 11:00. Calendar invite sent. Demo environment prepared.', type: 'success' },
  'Send Draft Reply': { message: 'AI-drafted reply sent for your review. Check your email drafts folder. Reply addresses client concern.', type: 'success' },
  'Approve & Send': { message: 'Proposal approved and sent to client via email. Delivery confirmation received. Follow-up scheduled in 3 days.', type: 'success' },
  'Upload Receipts': { message: 'Upload dialog opened. Drag & drop receipts or select files from your device.', type: 'info' },
  'Add to Segment': { message: 'Contact added to outreach segment. Will be included in next outreach batch.', type: 'success' },
  'View Lead': { message: 'Opening lead details. Contact info, project scope, and lead score displayed.', type: 'info' },
  'Send SMS': { message: 'SMS sent to prospect with consultation booking link. Delivery confirmed.', type: 'success' },
  'View Project': { message: 'Opening project details. Timeline, crew assignments, and milestone progress displayed.', type: 'info' },
  'Contact Client': { message: 'Initiating call to client. Project status and recent notes loaded.', type: 'info' },
  'View Deal': { message: 'Opening financing deal details. Preapproval status and expiry date displayed.', type: 'info' },
  'Send Reminder': { message: 'Reminder sent to client about expiring preapproval. Follow-up call logged.', type: 'success' },
  'View Sub': { message: 'Opening subcontractor profile. License, insurance, and performance ratings displayed.', type: 'info' },
  'Send Renewal': { message: 'Insurance renewal reminder sent to subcontractor. Expiry tracked in system.', type: 'success' },
  'Pause Jobs': { message: 'Subcontractor paused from new job assignments. Active projects unaffected.', type: 'success' },
  'View Invoice': { message: 'Opening invoice details. Line items and PO matching information displayed.', type: 'info' },
  'Find PO': { message: 'Searching for matching PO in QuickBooks... Displaying potential matches.', type: 'info' },
  'Contact Vendor': { message: 'Initiating call to vendor. Invoice details and discrepancy notes loaded.', type: 'info' },
  'View Profile': { message: 'Opening sales rep profile. Pipeline, close rate, and deal history displayed.', type: 'info' },
  'Schedule Coaching': { message: 'Coaching session scheduled. Sales training materials and best practices prepared.', type: 'success' },
};

export default function OverviewPage() {
  const { openDoc } = useDocViewer();
  const api = useApi();
  const agents = api.connected ? api.agents : mockAgents;
  const [attentionItems, setAttentionItems] = useState(initialAttentionItems);
  const [completedActions, setCompletedActions] = useState<Record<string, string[]>>({});
  const running = agents.filter(a => a.status === 'running').length;
  const todayLogs = executionLogs.filter(l => l.startedAt.startsWith('2026-03-21'));
  const successRate = Math.round(
    (executionLogs.filter(l => l.status === 'success').length / executionLogs.length) * 100
  );

  const handleAction = (itemId: string, action: string, item: AttentionItem) => {
    // Dismiss — remove the item with animation
    if (action === 'Dismiss') {
      setAttentionItems(prev => prev.filter(i => i.id !== itemId));
      addToast('Item dismissed', 'info');
      return;
    }

    // View/Review actions — open document viewer if available
    if (['Review Now', 'View Details', 'View Reply', 'View Email'].includes(action)) {
      if (item.docId && item.docName) {
        openDoc({ id: item.docId, name: item.docName, format: 'PDF', agent: item.agent, department: '', date: 'Mar 21', status: 'draft' });
      } else {
        openDoc({ id: itemId, name: item.text.split('—')[0].trim(), format: 'PDF', agent: item.agent, department: '', date: 'Mar 21', status: 'active' });
      }
      return;
    }

    // Mark action as completed on the item
    setCompletedActions(prev => ({
      ...prev,
      [itemId]: [...(prev[itemId] || []), action],
    }));

    // Show rich feedback
    const feedback = actionFeedback[action];
    if (feedback) {
      addToast(feedback.message, feedback.type);
    } else {
      addToast(`${action} — completed successfully`, 'success');
    }

    // For "Approve & Send" — remove item after short delay
    if (action === 'Approve & Send') {
      setTimeout(() => {
        setAttentionItems(prev => prev.filter(i => i.id !== itemId));
      }, 1500);
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Operations Overview</h1>
        <p className="text-sm text-gray-500 mt-1">Acme Home Improvement — Operations Dashboard</p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard icon={Zap} label="Active Agents" value={agents.length} sub={api.connected ? `Live — ${api.clientName}` : 'Demo mode'} />
        <StatCard icon={Activity} label="Running Now" value={running} sub={running > 0 ? 'Processing tasks' : 'All idle'} />
        <StatCard icon={CheckCircle2} label="Today's Runs" value={todayLogs.length} sub="Completed today" />
        <StatCard icon={Clock} label="Success Rate" value={`${successRate}%`} sub="Last 30 days" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left: Approvals & Attention — 3 cols */}
        <div className="lg:col-span-3">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <h2 className="text-lg font-semibold text-white">Needs Your Attention</h2>
            <span className="text-xs font-medium text-yellow-400 bg-yellow-500/20 px-2 py-0.5 rounded-full">{attentionItems.length}</span>
          </div>

          <div className="space-y-3">
            {attentionItems.length === 0 && (
              <div className="text-center py-8 text-gray-500 border border-surface-border rounded-xl bg-surface-raised">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-accent-400 opacity-60" />
                <p className="text-sm">All caught up! No items need attention.</p>
              </div>
            )}
            {attentionItems.map(item => {
              const pLabel = priorityLabels[item.priority];
              const itemCompleted = completedActions[item.id] || [];
              return (
                <div
                  key={item.id}
                  className={`border rounded-xl p-4 transition-all duration-300 ${priorityStyles[item.priority]}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md uppercase ${pLabel.color}`}>
                          {pLabel.text}
                        </span>
                        <span className="text-xs text-gray-500">{item.agent}</span>
                      </div>
                      <p className="text-sm text-white font-medium">{item.text}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {item.actions.map((action, ai) => {
                      const AIcon = actionIcons[action] || Eye;
                      const isDismiss = action === 'Dismiss';
                      const isPrimary = ai === 0;
                      const isCompleted = itemCompleted.includes(action);
                      return (
                        <button
                          key={ai}
                          disabled={isCompleted}
                          onClick={() => handleAction(item.id, action, item)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                            isCompleted
                              ? 'bg-accent-500/20 text-accent-400 border-accent-500/30 cursor-default'
                              : isDismiss
                              ? 'bg-surface-overlay text-gray-400 hover:text-gray-200 border-surface-border'
                              : isPrimary
                              ? 'bg-brand-500/15 text-brand-400 hover:bg-brand-500/25 border-brand-500/20'
                              : 'bg-accent-500/15 text-accent-400 hover:bg-accent-500/25 border-accent-500/20'
                          }`}
                        >
                          {isCompleted ? <CheckCircle2 className="w-3 h-3" /> : <AIcon className="w-3 h-3" />}
                          {isCompleted ? `${action} ✓` : action}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Recent Documents — 2 cols */}
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-4 h-4 text-brand-400" />
            <h2 className="text-lg font-semibold text-white">Recent Documents</h2>
          </div>

          <div className="space-y-2">
            {recentDocuments.map((doc) => (
              <div
                key={doc.id}
                className="bg-surface-raised border border-surface-border rounded-xl p-3 hover:border-brand-500/30 transition-all group cursor-pointer"
                onClick={() => openDoc({ id: doc.id, name: doc.name, format: doc.type, agent: doc.agent, department: '', date: doc.date, status: 'final' })}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3 min-w-0">
                    <FileText className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-white font-medium truncate">{doc.name}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{doc.agent} · {doc.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] text-gray-500">{doc.size}</span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${tagStyles[doc.type] || 'bg-gray-500/20 text-gray-400'}`}>
                      {doc.type}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => { e.stopPropagation(); openDoc({ id: doc.id, name: doc.name, format: doc.type, agent: doc.agent, department: '', date: doc.date, status: 'final' }); }}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium text-brand-400 bg-brand-500/10 hover:bg-brand-500/20 border border-brand-500/20"
                  >
                    <Eye className="w-3 h-3" />
                    View
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); addToast(`Editing ${doc.name}`, 'info'); }}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium text-gray-300 bg-surface-overlay hover:bg-surface-overlay/80 border border-surface-border"
                  >
                    <Pencil className="w-3 h-3" />
                    Edit
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); addToast(`Downloading ${doc.name}`, 'success'); }}
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium text-gray-300 bg-surface-overlay hover:bg-surface-overlay/80 border border-surface-border"
                  >
                    <Download className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent activity feed */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold text-white mb-4">Recent Activity</h2>
        <div className="bg-surface-raised border border-surface-border rounded-xl divide-y divide-surface-border">
          {todayLogs.slice(0, 6).map(log => {
            const statusLabel = log.status === 'success' ? 'Success' : log.status === 'partial' ? 'Partial' : 'Failed';
            const statusColor = log.status === 'success' ? 'text-accent-400' : log.status === 'partial' ? 'text-yellow-400' : 'text-red-400';
            return (
              <div key={log.id} className="flex items-center gap-4 px-4 py-3">
                <span className={`text-xs font-medium ${statusColor} w-14`}>{statusLabel}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white truncate">{log.summary}</p>
                  <p className="text-xs text-gray-500">{log.agentName}</p>
                </div>
                <span className="text-xs text-gray-500 shrink-0">
                  {new Date(log.startedAt).toLocaleTimeString('en-IL', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
